import { useState, FormEvent } from "react";
import { toast } from "sonner";
import {
  Menu, X, ArrowUpRight, Image as ImageIcon, Film, Users, Instagram, LayoutTemplate, Megaphone, Sparkles,
  Mail, MessageCircle, Heart, Play, Wand2, Target, Layers, TrendingUp, Camera,
} from "lucide-react";
import FadeInSection from "@/components/FadeInSection";
import workVideo from "@/assets/work-video.jpg";
import workProduct from "@/assets/work-product.jpg";
import workReel from "@/assets/work-reel.jpg";
import workPromo from "@/assets/work-promo.jpg";

const WHATSAPP = "https://wa.me/919653723630";
const EMAIL = "bkudratkaur@gmail.com";

// Replace with Kudrat's real portrait (e.g. import portrait from "@/assets/portrait.jpg")
const PORTRAIT: string | null = null;

const nav = [
  ["Home", "#home"], ["About", "#about"], ["Services", "#services"],
  ["Portfolio", "#portfolio"], ["Skills", "#skills"], ["Contact", "#contact"],
];

const Portrait = ({ className = "" }: { className?: string }) =>
  PORTRAIT ? (
    <img src={PORTRAIT} alt="Kudrat Kaur" className={`object-cover ${className}`} />
  ) : (
    <div className={`bg-secondary flex flex-col items-center justify-center text-center p-6 ${className}`}>
      <Camera className="w-10 h-10 text-primary mb-3" />
      <p className="font-display text-xl text-primary">Kudrat Kaur</p>
      <p className="text-xs text-muted-foreground mt-1">Portrait coming soon</p>
    </div>
  );

const Eyebrow = ({ children }: { children: React.ReactNode }) => (
  <p className="text-xs uppercase tracking-[0.3em] text-primary font-semibold mb-4">{children}</p>
);

const Btn = ({ href, children, variant = "solid" }: { href: string; children: React.ReactNode; variant?: "solid" | "ghost" | "light" }) => {
  const styles = {
    solid: "bg-primary text-primary-foreground hover:shadow-soft",
    ghost: "border border-foreground/20 hover:border-primary hover:text-primary",
    light: "bg-background text-foreground hover:bg-secondary",
  }[variant];
  return (
    <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer"
      className={`group inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 ${styles}`}>
      {children}
      <ArrowUpRight className="w-4 h-4 transition-transform group-hover:rotate-45" />
    </a>
  );
};

const Header = () => {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-background/75 backdrop-blur-lg border-b border-border/60">
      <div className="container flex items-center justify-between h-16">
        <a href="#home" className="font-display text-lg font-semibold tracking-[0.15em]">KUDRAT KAUR</a>
        <nav className="hidden lg:flex gap-8 text-sm">
          {nav.map(([l, h]) => <a key={h} href={h} className="hover:text-primary transition-colors">{l}</a>)}
        </nav>
        <a href="#contact" className="hidden lg:inline-flex rounded-full bg-primary text-primary-foreground px-5 py-2.5 text-sm font-semibold hover:-translate-y-0.5 transition-transform">Let's Work Together</a>
        <button className="lg:hidden p-2" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      <div className={`lg:hidden overflow-hidden transition-all duration-500 ${open ? "max-h-[480px]" : "max-h-0"}`}>
        <nav className="container flex flex-col gap-1 pb-6">
          {nav.map(([l, h]) => (
            <a key={h} href={h} onClick={() => setOpen(false)} className="font-display text-2xl py-2 border-b border-border/60">{l}</a>
          ))}
          <a href="#contact" onClick={() => setOpen(false)} className="mt-4 text-center rounded-full bg-primary text-primary-foreground py-3 font-semibold">Let's Work Together</a>
        </nav>
      </div>
    </header>
  );
};

const Hero = () => (
  <section id="home" className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 overflow-hidden">
    <div className="absolute -top-32 -right-32 w-[520px] h-[520px] rounded-full bg-brand opacity-20 blur-3xl" />
    <div className="container grid lg:grid-cols-12 gap-12 items-center relative">
      <div className="lg:col-span-7 animate-rise">
        <p className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-4 py-1.5 text-xs font-medium mb-8">
          <span className="w-2 h-2 rounded-full bg-accent" /> 1+ Year of Creative Editing Experience
        </p>
        <h1 className="text-5xl sm:text-6xl xl:text-7xl font-light leading-[1.02]">
          Creative Visuals.<br /><em className="text-brand font-normal">Powerful</em> Digital Presence.
        </h1>
        <p className="mt-8 max-w-xl text-lg text-muted-foreground leading-relaxed">
          Hi, I'm Kudrat Kaur — a creative photo & video editor and social media creator helping brands and individuals turn ideas into engaging visual content.
        </p>
        <div className="mt-10 flex flex-wrap gap-4">
          <Btn href="#portfolio">View My Work</Btn>
          <Btn href="#contact" variant="ghost">Let's Work Together</Btn>
        </div>
      </div>
      <div className="lg:col-span-5 relative h-[460px] sm:h-[540px]">
        <Portrait className="absolute right-0 top-0 w-[72%] h-[82%] rounded-[2rem] shadow-soft" />
        <img src={workReel} alt="Reel editing sample" width={1024} height={1280}
          className="absolute left-0 bottom-0 w-[46%] aspect-[4/5] object-cover rounded-3xl border-4 border-background shadow-soft animate-float" />
        <div className="absolute right-4 bottom-6 rounded-2xl bg-card/80 backdrop-blur-md border border-border px-4 py-3 shadow-soft flex items-center gap-3">
          <span className="w-9 h-9 rounded-full bg-brand flex items-center justify-center"><Play className="w-4 h-4 text-primary-foreground fill-current" /></span>
          <div className="text-xs"><p className="font-semibold">Reels · Edits · Content</p><p className="text-muted-foreground">Made for your feed</p></div>
        </div>
      </div>
    </div>
  </section>
);

const Marquee = () => {
  const items = ["Photo Editing", "Video Editing", "Reels", "Thumbnails", "Social Media", "Promotional Content", "Digital Branding"];
  return (
    <div className="bg-ink text-ink-foreground py-5 overflow-hidden">
      <div className="flex w-max animate-marquee">
        {[...items, ...items].map((t, i) => (
          <span key={i} className="font-display italic text-2xl px-8 flex items-center gap-8">{t} <Sparkles className="w-4 h-4 text-accent" /></span>
        ))}
      </div>
    </div>
  );
};

const About = () => (
  <section id="about" className="py-24 lg:py-32">
    <div className="container grid lg:grid-cols-2 gap-16 items-center">
      <FadeInSection>
        <Portrait className="w-full max-w-md aspect-[4/5] rounded-[2rem] mx-auto" />
      </FadeInSection>
      <FadeInSection delay={150}>
        <Eyebrow>About Me</Eyebrow>
        <h2 className="text-4xl lg:text-5xl font-light leading-tight">A Creative Mind Behind the <em className="text-brand">Content</em></h2>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          I'm Kudrat — a young digital creator who loves turning raw footage and simple photos into visuals people stop scrolling for. Over around 12 months with iDigitalPreneur, I've built hands-on experience in photo editing, video editing, reels, promotional content and visual storytelling.
        </p>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          Today I'm growing into social media handling and content creation — helping people present themselves consistently and beautifully online.
        </p>
        <blockquote className="mt-8 border-l-2 border-accent pl-5 font-display italic text-xl">
          "From editing visuals to building complete social-media content experiences."
        </blockquote>
        <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[["01+", "Year Experience"], ["✦", "Creative Editing"], ["✦", "Social Media"], ["✦", "Content Creation"]].map(([n, l]) => (
            <div key={l} className="rounded-2xl bg-card border border-border p-4">
              <p className="font-display text-2xl text-primary">{n}</p>
              <p className="text-xs text-muted-foreground mt-1">{l}</p>
            </div>
          ))}
        </div>
      </FadeInSection>
    </div>
  </section>
);

const skills = ["Photo Editing", "Video Editing", "Reels Editing", "Social Media Handling", "Social Media Content Creation", "Instagram Content", "Promotional Videos", "Thumbnail Design", "Creative Retouching", "Visual Storytelling", "Content Planning", "Basic Branding", "Digital Content Strategy"];

const Skills = () => (
  <section id="skills" className="py-24 bg-secondary/50">
    <div className="container text-center">
      <FadeInSection>
        <Eyebrow>Skills</Eyebrow>
        <h2 className="text-4xl lg:text-5xl font-light">What I Bring to <em className="text-brand">Every Frame</em></h2>
      </FadeInSection>
      <div className="mt-14 flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
        {skills.map((s, i) => (
          <FadeInSection key={s} delay={i * 40}>
            <span className="inline-block rounded-full border border-primary/20 bg-card px-6 py-3 text-sm font-medium transition-all duration-300 hover:bg-primary hover:text-primary-foreground hover:-translate-y-1 cursor-default">{s}</span>
          </FadeInSection>
        ))}
      </div>
    </div>
  </section>
);

const services = [
  [ImageIcon, "Photo Editing", "Professional image enhancement, retouching, creative editing, social-media visuals, and promotional imagery."],
  [Film, "Video Editing", "Short-form videos, reels, promotional videos, transitions, pacing, text overlays, and engaging visual storytelling."],
  [Users, "Social Media Management", "Content organization, creative posting, visuals, reels, captions, and a consistent online presence."],
  [Instagram, "Instagram & Reels", "Scroll-stopping reels, visual hooks, transitions, and platform-friendly creative content."],
  [LayoutTemplate, "Thumbnail & Creative Design", "Attractive thumbnails and promotional graphics designed to improve visual appeal."],
  [Megaphone, "Promotional Content", "Creative visuals for businesses, products, services, offers, events, and personal brands."],
  [Sparkles, "Content Creation", "Complete creative support combining editing, design, storytelling, and social presentation."],
] as const;

const Services = () => (
  <section id="services" className="py-24 lg:py-32">
    <div className="container">
      <FadeInSection className="max-w-2xl">
        <Eyebrow>Services</Eyebrow>
        <h2 className="text-4xl lg:text-5xl font-light leading-tight">Creative Editing. Powerful Content. <em className="text-brand">Stronger Social Presence.</em></h2>
      </FadeInSection>
      <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {services.map(([Icon, t, d], i) => (
          <FadeInSection key={t} delay={i * 60} className={i === 6 ? "lg:col-span-3" : ""}>
            <div className={`group h-full rounded-3xl border border-border bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:shadow-soft ${i === 6 ? "bg-ink text-ink-foreground border-transparent" : ""}`}>
              <span className="w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center transition-colors group-hover:bg-brand">
                <Icon className="w-5 h-5 text-primary group-hover:text-primary-foreground" />
              </span>
              <h3 className="mt-6 text-2xl">{t}</h3>
              <p className={`mt-3 text-sm leading-relaxed ${i === 6 ? "opacity-70" : "text-muted-foreground"}`}>{d}</p>
            </div>
          </FadeInSection>
        ))}
      </div>
    </div>
  </section>
);

const Experience = () => (
  <section className="py-24 bg-ink text-ink-foreground">
    <div className="container grid lg:grid-cols-3 gap-12">
      <FadeInSection>
        <p className="text-xs uppercase tracking-[0.3em] text-accent font-semibold mb-4">Experience</p>
        <h2 className="text-4xl lg:text-5xl font-light">The Journey <em className="text-accent">So Far</em></h2>
      </FadeInSection>
      <div className="lg:col-span-2 relative border-l border-ink-foreground/20 pl-8 space-y-14">
        {[
          ["~12 months", "iDigitalPreneur", "Creative Editing & Digital Content", ["Photo editing", "Video editing", "Digital content creation", "Creative visual development"]],
          ["Now", "Current Development", "Social Media Handling & Content Creation", ["Social media handling", "Content planning", "Reels & short-form", "Consistent brand presence"]],
        ].map(([when, title, sub, list], i) => (
          <FadeInSection key={title as string} delay={i * 150} className="relative">
            <span className="absolute -left-[41px] top-1 w-4 h-4 rounded-full bg-accent ring-4 ring-[hsl(var(--ink))]" />
            <p className="text-xs uppercase tracking-widest text-accent">{when}</p>
            <h3 className="text-3xl mt-2">{title}</h3>
            <p className="opacity-70 mt-1">{sub}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              {(list as string[]).map((l) => <span key={l} className="text-xs rounded-full border border-ink-foreground/20 px-3 py-1.5">{l}</span>)}
            </div>
          </FadeInSection>
        ))}
      </div>
    </div>
  </section>
);

// Sample projects — replace with Kudrat's real work
const projects = [
  { title: "Social Media Reel", cat: "Reels", img: workReel, desc: "Short-form fashion reel with hooks, pacing and text overlays.", tall: true },
  { title: "Product Visual", cat: "Photo Editing", img: workProduct, desc: "Clean product retouching and presentation for a demo brand." },
  { title: "Promotional Campaign", cat: "Promotional Content", img: workPromo, desc: "Moody colour-graded promo visual for a fictional café." },
  { title: "Video Edit Project", cat: "Video Editing", img: workVideo, desc: "Timeline-based edit with transitions and colour work.", tall: true },
  { title: "Instagram Content", cat: "Social Media", img: workReel, desc: "A coordinated post and reel design system." },
  { title: "Thumbnail Design", cat: "Thumbnails", img: workPromo, desc: "High-impact thumbnail concept built to get clicks." },
];
const cats = ["All", "Photo Editing", "Video Editing", "Reels", "Social Media", "Promotional Content", "Thumbnails"];

const Portfolio = () => {
  const [cat, setCat] = useState("All");
  const shown = projects.filter((p) => cat === "All" || p.cat === cat);
  return (
    <section id="portfolio" className="py-24 lg:py-32">
      <div className="container">
        <FadeInSection className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
          <div>
            <Eyebrow>Selected Work</Eyebrow>
            <h2 className="text-4xl lg:text-6xl font-light">Turning Ideas Into <em className="text-brand">Visual Content.</em></h2>
            <p className="mt-3 text-sm text-muted-foreground">Sample projects showing the styles I work in.</p>
          </div>
        </FadeInSection>
        <div className="mt-10 flex gap-2 overflow-x-auto pb-2 -mx-2 px-2">
          {cats.map((c) => (
            <button key={c} onClick={() => setCat(c)}
              className={`shrink-0 rounded-full px-5 py-2 text-sm transition-colors ${cat === c ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-secondary/70"}`}>{c}</button>
          ))}
        </div>
        <div className="mt-10 columns-1 sm:columns-2 lg:columns-3 gap-5 [&>*]:mb-5">
          {shown.map((p) => (
            <article key={p.title} className="group break-inside-avoid relative overflow-hidden rounded-3xl bg-muted">
              <img src={p.img} alt={p.title} loading="lazy" width={1024} height={p.tall ? 1280 : 1024}
                className={`w-full object-cover transition-transform duration-700 group-hover:scale-105 ${p.tall ? "aspect-[4/5]" : "aspect-square"}`} />
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--ink)/0.85)] via-transparent to-transparent" />
              <div className="absolute bottom-0 inset-x-0 p-6 text-ink-foreground">
                <p className="text-[11px] uppercase tracking-widest text-accent">{p.cat}</p>
                <h3 className="text-2xl mt-1">{p.title}</h3>
                <p className="text-sm opacity-80 mt-1 max-h-0 overflow-hidden group-hover:max-h-20 transition-all duration-500">{p.desc}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold">View Project <ArrowUpRight className="w-4 h-4" /></span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const Process = () => (
  <section className="py-24 bg-secondary/50">
    <div className="container">
      <FadeInSection className="text-center">
        <Eyebrow>Creative Process</Eyebrow>
        <h2 className="text-4xl lg:text-5xl font-light">How We'll <em className="text-brand">Work Together</em></h2>
      </FadeInSection>
      <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {[["01", "Understand", "Understand the brand, idea, audience, and objective."], ["02", "Create", "Develop the visual concept and editing direction."], ["03", "Refine", "Polish the visuals, timing, composition, and details."], ["04", "Deliver", "Deliver professional, platform-ready content."]].map(([n, t, d], i) => (
          <FadeInSection key={n} delay={i * 100}>
            <div className="h-full rounded-3xl bg-card p-8 border border-border hover:shadow-soft transition-shadow">
              <p className="font-display text-6xl text-brand font-light">{n}</p>
              <h3 className="text-2xl mt-6">{t}</h3>
              <p className="text-sm text-muted-foreground mt-2">{d}</p>
            </div>
          </FadeInSection>
        ))}
      </div>
    </div>
  </section>
);

const Social = () => (
  <section className="py-24 lg:py-32 overflow-hidden">
    <div className="container grid lg:grid-cols-2 gap-16 items-center">
      <FadeInSection>
        <Eyebrow>Social Media & Content</Eyebrow>
        <h2 className="text-4xl lg:text-5xl font-light leading-tight">Content That Belongs on <em className="text-brand">Your Feed</em></h2>
        <ul className="mt-8 grid grid-cols-2 gap-3 text-sm">
          {["Instagram posts", "Reels", "Stories", "Promotional graphics", "Video thumbnails", "Before/after edits"].map((x) => (
            <li key={x} className="flex items-center gap-2"><Heart className="w-4 h-4 text-accent fill-current" />{x}</li>
          ))}
        </ul>
        <p className="mt-10 font-display text-2xl">Need Content for Your Social Media? <em className="text-primary">Let's Create It.</em></p>
        <div className="mt-6"><Btn href={WHATSAPP}>Chat on WhatsApp</Btn></div>
      </FadeInSection>
      <FadeInSection delay={150} className="relative flex justify-center">
        <div className="w-64 sm:w-72 rounded-[2.5rem] bg-ink p-3 shadow-soft rotate-[-4deg]">
          <div className="rounded-[2rem] bg-background overflow-hidden">
            <div className="flex items-center gap-2 p-3">
              <span className="w-8 h-8 rounded-full bg-brand" />
              <span className="text-xs font-semibold">your.brand</span>
            </div>
            <div className="grid grid-cols-3 gap-0.5">
              {[workReel, workProduct, workPromo, workVideo, workPromo, workReel, workProduct, workVideo, workReel].map((s, i) => (
                <img key={i} src={s} alt="" loading="lazy" className="aspect-square object-cover" />
              ))}
            </div>
          </div>
        </div>
        <div className="absolute -right-2 sm:right-8 top-10 w-32 rounded-2xl overflow-hidden border-4 border-background shadow-soft rotate-6 animate-float">
          <img src={workReel} alt="" loading="lazy" className="aspect-[9/16] object-cover" />
        </div>
      </FadeInSection>
    </div>
  </section>
);

const Why = () => (
  <section className="py-24 bg-secondary/50">
    <div className="container">
      <FadeInSection>
        <Eyebrow>Why Work With Me</Eyebrow>
        <h2 className="text-4xl lg:text-5xl font-light max-w-2xl">Thoughtful, polished and <em className="text-brand">made for today's platforms.</em></h2>
      </FadeInSection>
      <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-5 gap-5">
        {[[Wand2, "Creative Approach", "Every project receives a thoughtful visual direction."], [Film, "Modern Editing", "Designed around current digital and social formats."], [Target, "Attention to Detail", "Clean, polished, professional visuals."], [Layers, "Multi-Skill Support", "Photo, video, social media and content in one place."], [TrendingUp, "Growing Expertise", "Continuously developing across editing and content."]].map(([Icon, t, d], i) => {
          const I = Icon as typeof Wand2;
          return (
            <FadeInSection key={t as string} delay={i * 80}>
              <div className="h-full">
                <I className="w-6 h-6 text-primary" />
                <h3 className="text-xl mt-4">{t as string}</h3>
                <p className="text-sm text-muted-foreground mt-2">{d as string}</p>
              </div>
            </FadeInSection>
          );
        })}
      </div>
    </div>
  </section>
);

const CTA = () => (
  <section className="py-24">
    <div className="container">
      <FadeInSection>
        <div className="relative overflow-hidden rounded-[2.5rem] bg-brand px-8 py-20 text-center text-primary-foreground">
          <div className="absolute -top-20 -left-20 w-72 h-72 rounded-full bg-background/10 blur-2xl animate-float" />
          <h2 className="relative text-4xl lg:text-6xl font-light max-w-3xl mx-auto">Have an Idea? <em>Let's Turn It Into Content.</em></h2>
          <p className="relative mt-6 max-w-2xl mx-auto opacity-90">Whether you need a polished photo, engaging video, social-media content, or a complete creative package, let's create something that stands out.</p>
          <div className="relative mt-10 flex flex-wrap justify-center gap-4">
            <Btn href="#contact" variant="light">Start a Project</Btn>
            <a href={`mailto:${EMAIL}`} className="inline-flex items-center rounded-full border border-primary-foreground/50 px-7 py-3.5 text-sm font-semibold hover:bg-primary-foreground/10 transition-colors">Contact Me</a>
          </div>
        </div>
      </FadeInSection>
    </div>
  </section>
);

const Contact = () => {
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const body = `Name: ${f.get("name")}\nEmail: ${f.get("email")}\nService: ${f.get("service")}\n\n${f.get("details")}`;
    window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent("New project enquiry")}&body=${encodeURIComponent(body)}`;
    toast.success("Opening your email app to send the message.");
  };
  const field = "w-full rounded-2xl border border-input bg-card px-5 py-3.5 text-sm outline-none focus:border-primary transition-colors";
  return (
    <section id="contact" className="py-24 lg:py-32">
      <div className="container grid lg:grid-cols-2 gap-16">
        <FadeInSection>
          <Eyebrow>Contact</Eyebrow>
          <h2 className="text-4xl lg:text-5xl font-light">Let's Create Something <em className="text-brand">Great</em></h2>
          <p className="mt-6 text-muted-foreground">Kudrat Kaur — reach out directly or send a few details about your project.</p>
          <div className="mt-10 space-y-4">
            <a href={WHATSAPP} target="_blank" rel="noreferrer" className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5 hover:border-primary transition-colors">
              <MessageCircle className="w-6 h-6 text-primary" /><div><p className="text-xs text-muted-foreground">WhatsApp</p><p className="font-semibold">+91 96537 23630</p></div>
            </a>
            <a href={`mailto:${EMAIL}`} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5 hover:border-primary transition-colors">
              <Mail className="w-6 h-6 text-primary" /><div><p className="text-xs text-muted-foreground">Email</p><p className="font-semibold break-all">{EMAIL}</p></div>
            </a>
          </div>
        </FadeInSection>
        <FadeInSection delay={150}>
          <form onSubmit={submit} className="space-y-4 rounded-[2rem] bg-secondary/50 p-6 sm:p-10">
            <input required name="name" maxLength={100} placeholder="Your name" className={field} />
            <input required name="email" type="email" maxLength={255} placeholder="Your email" className={field} />
            <select required name="service" defaultValue="" className={field}>
              <option value="" disabled>Service required</option>
              {services.map(([, t]) => <option key={t}>{t}</option>)}
            </select>
            <textarea required name="details" rows={5} maxLength={1500} placeholder="Project details" className={field} />
            <button className="w-full rounded-full bg-primary text-primary-foreground py-4 font-semibold hover:shadow-soft transition-shadow">Send Message</button>
          </form>
        </FadeInSection>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="bg-ink text-ink-foreground pt-16 pb-8">
    <div className="container grid md:grid-cols-3 gap-10">
      <div>
        <p className="font-display text-2xl">Kudrat Kaur</p>
        <p className="text-sm opacity-70 mt-2">Photo Editor • Video Editor • Social Media Creator</p>
      </div>
      <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
        {nav.filter(([l]) => l !== "Skills").map(([l, h]) => <a key={h} href={h} className="opacity-80 hover:text-accent">{l}</a>)}
      </nav>
      <div className="text-sm space-y-1 md:text-right">
        <a href={WHATSAPP} className="block hover:text-accent">+91 96537 23630</a>
        <a href={`mailto:${EMAIL}`} className="block hover:text-accent">{EMAIL}</a>
      </div>
    </div>
    <p className="container mt-12 pt-6 border-t border-ink-foreground/15 text-xs opacity-60">© 2026 Kudrat Kaur. All Rights Reserved.</p>
  </footer>
);

const Index = () => (
  <main>
    <Header />
    <Hero />
    <Marquee />
    <About />
    <Skills />
    <Services />
    <Experience />
    <Portfolio />
    <Process />
    <Social />
    <Why />
    <CTA />
    <Contact />
    <Footer />
    <a href={WHATSAPP} target="_blank" rel="noreferrer" aria-label="WhatsApp"
      className="fixed bottom-5 right-5 z-40 w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-soft hover:scale-110 transition-transform">
      <MessageCircle className="w-6 h-6" />
    </a>
  </main>
);

export default Index;
